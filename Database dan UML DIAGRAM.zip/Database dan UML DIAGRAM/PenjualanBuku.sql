-- Buat Database
CREATE DATABASE PenjualanBuku;
GO

-- Gunakan Database
USE PenjualanBuku;
GO

-- Tabel Buku
CREATE TABLE Buku (
    IdBuku INT PRIMARY KEY IDENTITY,
    Judul NVARCHAR(100) NOT NULL,
	Genre VARCHAR(100) NOT NULL,
    Penulis NVARCHAR(100) NOT NULL,
    Penerbit NVARCHAR(100) NOT NULL,
    Harga DECIMAL(18,2) NOT NULL,
    Stok INT 
);

-- Tabel Pelanggan
CREATE TABLE Pelanggan (
    IdPelanggan INT PRIMARY KEY IDENTITY,
    Nama NVARCHAR(100) NOT NULL,
	Email NVARCHAR(255) NOT NULL,
	[Password] NVARCHAR(255) NOT NULL,
    Alamat NVARCHAR(200) NOT NULL,
    Telepon NVARCHAR(20),
	isAdmin BIT Not Null DEFAULT 0
);

-- Tabel Transaksi
CREATE TABLE Transaksi (
    IdTransaksi INT PRIMARY KEY IDENTITY,
    IdPelanggan INT FOREIGN KEY REFERENCES Pelanggan(IdPelanggan),
    Tanggal DATETIME DEFAULT GETDATE()
);

-- Tabel DetailTransaksi
CREATE TABLE DetailTransaksi (
    IdDetail INT PRIMARY KEY IDENTITY,
    IdTransaksi INT FOREIGN KEY REFERENCES Transaksi(IdTransaksi),
    IdBuku INT FOREIGN KEY REFERENCES Buku(IdBuku),
    Jumlah INT NOT NULL,
    HargaSaatTransaksi DECIMAL(18,2),
    Subtotal AS (Jumlah * HargaSaatTransaksi) PERSISTED
);
